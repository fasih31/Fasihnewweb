import { useEffect } from "react";

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  ogImage?: string;
  canonicalUrl?: string;
}

export function SEOHead({
  title = "Fasih ur Rehman | Product Manager | AI, Web3, FinTech Expert",
  description = "Certified Product Manager (PMP) with 9+ years of experience in AI/AGI, Web3, FinTech, EdTech, and eCommerce. Delivering innovative, user-centric solutions that drive measurable business growth.",
  keywords = "product manager, AI, Web3, FinTech, EdTech, eCommerce, PMP, certified product manager, digital transformation, agile, scrum",
  ogImage = "/og-image.png",
  canonicalUrl,
}: SEOHeadProps) {
  useEffect(() => {
    document.title = title;

    const updateMeta = (name: string, content: string) => {
      let element = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement;
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute("name", name);
        document.head.appendChild(element);
      }
      element.setAttribute("content", content);
    };

    const updateProperty = (property: string, content: string) => {
      let element = document.querySelector(`meta[property="${property}"]`) as HTMLMetaElement;
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute("property", property);
        document.head.appendChild(element);
      }
      element.setAttribute("content", content);
    };

    updateMeta("description", description);
    updateMeta("keywords", keywords);
    updateMeta("author", "Fasih ur Rehman");
    updateMeta("robots", "index, follow");
    updateMeta("viewport", "width=device-width, initial-scale=1");

    updateProperty("og:title", title);
    updateProperty("og:description", description);
    updateProperty("og:type", "website");
    updateProperty("og:image", ogImage);
    if (canonicalUrl) {
      updateProperty("og:url", canonicalUrl);
    }

    updateMeta("twitter:card", "summary_large_image");
    updateMeta("twitter:title", title);
    updateMeta("twitter:description", description);
    updateMeta("twitter:image", ogImage);

    if (canonicalUrl) {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
      if (!link) {
        link = document.createElement("link");
        link.setAttribute("rel", "canonical");
        document.head.appendChild(link);
      }
      link.setAttribute("href", canonicalUrl);
    }
  }, [title, description, keywords, ogImage, canonicalUrl]);

  return null;
}

export function StructuredData() {
  useEffect(() => {
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "Person",
      name: "Fasih ur Rehman",
      jobTitle: "Product Manager",
      description: "Certified Product Manager (PMP) specializing in AI/AGI, Web3, FinTech, EdTech, and eCommerce solutions",
      knowsAbout: ["Product Management", "AI", "Web3", "FinTech", "EdTech", "eCommerce", "Agile", "Scrum"],
      hasCredential: {
        "@type": "EducationalOccupationalCredential",
        credentialCategory: "certification",
        name: "Project Management Professional (PMP)",
      },
    };

    let script = document.querySelector('script[type="application/ld+json"]');
    if (!script) {
      script = document.createElement("script");
      script.setAttribute("type", "application/ld+json");
      document.head.appendChild(script);
    }
    script.textContent = JSON.stringify(structuredData);
  }, []);

  return null;
}
